package com.qa.pages;

import org.openqa.selenium.support.PageFactory;

import com.qa.utilities.Utils;

public class HomePage extends Utils{
	
	
	
	
	
	
	
	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	
	

}
